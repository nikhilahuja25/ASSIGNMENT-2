﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Question_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double Pamount;
            bool crctnm = double.TryParse(textBox1.Text, out Pamount);
            double time;
            bool crcttym = double.TryParse(textBox2.Text, out time);
            string opt = comboBox1.Text;
            string Famount;
            bool allset;

            if(!crctnm)
            {
                MessageBox.Show("Principal amount should be a number greater than zero");
                allset = false;
            }
            else
            {
                allset = true;
            }

            if(!crcttym)
            {
                MessageBox.Show("Time should be a number greater than zero and should be in hours");
                allset = false;
            }
            else
            {
                allset = true;
            }

            if(Pamount <0 && time <0)
            {
                MessageBox.Show("Principal amount and time can not be zero or less");
                allset = false;
            }
            else
            {
                allset = true;
            }

            if(allset)
            {
                if (opt == "SBI")
                {
                    Bank sbi = new SBI();
                    Famount = sbi.getRateOfInterest(Pamount, time).ToString();
                    textBox3.Text = Famount;
                }

                else if (opt == "ICICI")
                {
                    Bank icici = new ICICI();
                    Famount = icici.getRateOfInterest(Pamount, time).ToString();
                    textBox3.Text = Famount;
                }

                else if (opt == "AXIS")
                {
                    Bank axis = new AXIS();
                    Famount = axis.getRateOfInterest(Pamount, time).ToString();
                    textBox3.Text = Famount;
                }

                else
                {
                    MessageBox.Show("Please select a bank from the list");
                }
            }

        }
    }
}
